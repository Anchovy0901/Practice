#!/usr/bin/env bash

python3 -m unittest discover $(pwd)
