<template>
  <div class="app-container">
<!--    搜索按钮栏-->
    <el-form :inline="true" :model="formInline" class="demo-form-inline">
      <el-form-item>
        <el-button type="primary" plain @click="dialogFormVisible = true">添加批次</el-button>
      </el-form-item>
<!--      刷新-->
      <el-form-item>
        <el-button type="info" plain icon="el-icon-refresh-left" @click="refresh"></el-button>
      </el-form-item>
<!--      添加批次弹框-->
      <el-dialog title="收货地址" :visible.sync="dialogFormVisible" width="500px">
        <el-form :model="form">
          <el-form-item label="生产总数" :label-width="formLabelWidth" >
            <el-input-number v-model="form.count" autocomplete="off" clearable placeholder="1-20万"
            min="1" max="200000" @change="toInteger" type="number"></el-input-number>
          </el-form-item>
          <el-form-item label="所在基地" :label-width="formLabelWidth">
            <el-select v-model="form.factoryid" placeholder="请选择所在基地" @change="getLines">
              <el-option v-for="(item,index) in factorys" :key="index" :label="item.factoryname"
                         :value=item.factoryid></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="所在产线" :label-width="formLabelWidth">
            <el-select v-model="form.lineid" placeholder="请选择所在产线">
              <el-option v-for="(item,index) in lines" :key="index" :label="item.linename"
                         :value=item.lineid></el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="addCodesection()">确 定</el-button>
        </div>
      </el-dialog>
      <el-form-item style="float:right;">
        <el-input
          placeholder="请输入内容"
          v-model="input"
          clearable
          style="width: 200px; margin-right: 20px"
        >
        </el-input>
        <el-button type="primary" icon="el-icon-search" @click="pageSearch()">搜索</el-button>
      </el-form-item>
    </el-form>
<!--    表格-->
    <el-table
      v-loading="listLoading"
      :data="codes"
      element-loading-text="Loading"
      border
      fit
      highlight-current-row
    >
      <el-table-column align="center" label="序号">
        <template slot-scope="scope">
          {{ scope.$index }}
        </template>
      </el-table-column>
      <el-table-column label="批次号" width="500" align="center">
        <template slot-scope="scope">
          {{ scope.row.verifycode}}
        </template>
      </el-table-column>
      <el-table-column label="基地名" width="200" align="center" >
        <template slot-scope="scope">
          <span>{{ scope.row.factoryname}}</span>
        </template>
      </el-table-column>
      <el-table-column label="产线名" width="200" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.linename}}</span>
        </template>
      </el-table-column>
<!--      下载按钮-->
      <el-table-column label="操作" align="center" width="300" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button v-if="scope.row.activeflag == 0" type="danger" disabled size="mini">
            不可下载
          </el-button>
          <el-button v-else type="primary" size="mini" @click="download(scope.row.verifycode)">
            下载
          </el-button>
        </template>
      </el-table-column>
    </el-table>
<!--    分页栏-->
    <div class="pagination">
      <el-pagination
        background
        layout="total, prev, pager, next"
        :current-page="query.pageIndex"
        :page-size="query.pageSize"
        :total="pageTotal"
        @current-change="handleCurrentChange"
        style="position: fixed;bottom: 20px;"
      ></el-pagination>
    </div>
  </div>
</template>

<script>
  import { Message } from 'element-ui'

  export default {
    inject: ['reload'],
    data() {
      return {
        listLoading: true,//等待
        codes: null,//批次
        input: '',//搜索框
        dialogFormVisible: false,//是否显示添加批次弹框
        form: {//添加批次信息
          count: 5000,
          factoryid: '',
          lineid:''
        },
        formLabelWidth: '120px',
        factorys:[],//工厂
        lines:[],//产线
        //分页
        query:{
          pageIndex:0,//当前页面所在行
          pageSize:9,//每页行数
        },
        pageTotal: 0,//总行数
      }
    },
    created() {
      // this.getCode();
      this.getFactorys();//得到所有工厂
      this.getData(this.query.pageIndex,this.query.pageSize,'=')//得到分页信息
    },
    methods: {
      //得到所有工厂
      getFactorys(){
        this.listLoading = true
        var vm = this
        this.axios({
          method: 'GET',
          url: 'findAllFactoryinfo'
        }).then(function(resp) {
          vm.factorys = resp.data
          vm.listLoading = false
        })
      },
      //得到对应产线 通过工厂id
      getLines(){
        this.listLoading = true
        var vm = this
        this.axios({
          method: 'POST',
          url: 'findLineByFactoryid',
          data:vm.form
        }).then(function(resp) {
          vm.lines = resp.data
          vm.listLoading = false
        })
      },
      //添加批次
      addCodesection(){
        var vm = this
        // console.log(vm.form)
        this.axios({
          method: 'POST',
          url: 'insertCode',
          data: vm.form
        }).then(function(resp) {
          if (resp.data.status === 200) {
            Message.success(resp.data.message)
          }
        })
        this.reload()
      },
      //得到分页信息
      getData(currentPage,pageSize,input){
        this.axios({
          method:'GET',
          url:'/page/'+currentPage+'/'+pageSize+'/'+input,
        })
          .then(res =>{
            console.log(res)
            this.codes = res.data.content;
            this.pageTotal = res.data.totalElements;
          })
      },
      //分页栏点击跳转
      handleCurrentChange(value){
        this.query.pageIndex = value;//获得当前页码
        if(!this.input){
          this.getData(this.query.pageIndex-1,this.query.pageSize,'=');
        }else{
          this.getData(this.query.pageIndex-1,this.query.pageSize,this.input);
        }
      },
      //下载批次对应原始码
      download(verifycode){
        this.axios({
          method:'GET',
          url:'/download/'+verifycode,
          responseType: 'blob'
        })
          .then(res =>{
            let blob = new Blob([res.data]);
            let url = window.URL.createObjectURL(blob);
            let a = document.createElement("a");
            a.href = url;
            a.download = verifycode
            // a.download = url.split('/').pop();
            a.click();
            window.URL.revokeObjectURL(url)

            this.axios({
              method:'POST',
              url:'downloadCode',
              data:{"verifycode":verifycode,"systemop":"下载人"}
            })
          })
      },
      //搜索功能
      pageSearch(){
        this.query.pageIndex=0
        this.query.pageSize=9
        if(!this.input){
          this.getData(this.query.pageIndex,this.query.pageSize,'=')
        }else{
          this.getData(this.query.pageIndex,this.query.pageSize,this.input)
        }
      },
      refresh(){
        if(this.query.pageIndex===0){
          if(!this.input){
            this.getData(this.query.pageIndex,this.query.pageSize,'=');
          }else{
            this.getData(this.query.pageIndex,this.query.pageSize,this.input);
          }
        }else{
          if(!this.input){
            this.getData(this.query.pageIndex-1,this.query.pageSize,'=');
          }else{
            this.getData(this.query.pageIndex-1,this.query.pageSize,this.input);
          }
        }

      }
    }
  }
</script>

